[![Build Status](https://travis-ci.com/jjhbriggs/testDjangoSite.svg?branch=master)](https://travis-ci.com/jjhbriggs/testDjangoSite)
[![codecov](https://codecov.io/gh/jjhbriggs/testDjangoSite/branch/master/graph/badge.svg)](https://codecov.io/gh/jjhbriggs/testDjangoSite)  
# Django Test Project  
Jack Briggs
