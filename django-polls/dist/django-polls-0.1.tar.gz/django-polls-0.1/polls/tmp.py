default_app_config = 'polls.apps.PollsConfig'
from .models import *
from .tests import *
from .urls import *
from .views import *
